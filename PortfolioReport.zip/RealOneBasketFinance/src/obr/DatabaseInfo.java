package obr;

//information to login into the database
public class DatabaseInfo {
    public static final String url = "jdbc:mysql://cse.unl.edu/tttran";
    public static final String username = "tttran";
    public static final String password = "8bkrrC";
}

