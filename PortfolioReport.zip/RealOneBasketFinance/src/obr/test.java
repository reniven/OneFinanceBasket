package obr;

import com.sdb.PortfolioData;

public class test {
	public static void main(String[] args) {
		//PortfolioData.addPerson("test", "firstname", "lastname", "teststreet", "testcity", "NE", "12345", "USA", null, null);
		PortfolioData.removeAllPortfolios();
	}

}
